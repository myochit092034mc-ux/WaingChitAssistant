package com.example.waingchit

import android.app.*
import android.content.*
import android.os.Bundle
import android.provider.Settings
import android.speech.*
import android.speech.tts.TextToSpeech
import android.widget.*
import java.util.*

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }
        val title = TextView(this).apply {
            text = "ဝိုင်းချစ် AI Assistant"
            textSize = 28f
        }
        status = TextView(this).apply {
            text = "ခလုတ်နှိပ်ပြီး “ဝိုင်းချစ်…” လို့ ပြောပါ"
            textSize = 18f
            setPadding(0, 30, 0, 30)
        }
        val button = Button(this).apply {
            text = "🎤 ဝိုင်းချစ်ကို ခေါ်မယ်"
            setOnClickListener { listen() }
        }
        layout.addView(title); layout.addView(status); layout.addView(button)
        setContentView(layout)

        tts = TextToSpeech(this, this)
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("ဒီဖုန်းမှာ အသံမှတ်မိစနစ် မရနိုင်သေးပါဘူး")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer!!.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle) {
                val text = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                status.text = "ကြားလိုက်တာ: $text"
                handleCommand(text)
            }
            override fun onError(error: Int) { status.text = "ထပ်ပြောပါ"; }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() { status.text = "နားထောင်နေပါတယ်…" }
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "my-MM")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        }
        recognizer!!.startListening(intent)
    }

    private fun handleCommand(raw: String) {
        val text = raw.lowercase(Locale.getDefault())
        when {
            text.contains("youtube") || text.contains("ယူတူး") -> {
                say("YouTube ဖွင့်ပေးမယ်")
                startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.youtube.com")))
            }
            text.contains("facebook") || text.contains("ဖေ့စ်ဘုတ်") -> {
                say("Facebook ဖွင့်ပေးမယ်")
                startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.facebook.com")))
            }
            text.contains("camera") || text.contains("ကင်မရာ") -> {
                say("Camera ဖွင့်ပေးမယ်")
                startActivity(Intent("android.media.action.IMAGE_CAPTURE"))
            }
            text.contains("alarm") || text.contains("နာရီ") -> {
                say("Alarm app ဖွင့်ပေးမယ်")
                startActivity(Intent(android.provider.AlarmClock.ACTION_SET_ALARM))
            }
            text.contains("wifi") || text.contains("ဝိုင်ဖိုင်") -> {
                say("Wi-Fi settings ဖွင့်ပေးမယ်")
                startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
            }
            else -> say("အခု command ကို မသိသေးပါဘူး။ YouTube၊ Facebook၊ Camera၊ Alarm၊ Wi-Fi လို့ ခိုင်းကြည့်ပါ")
        }
    }

    private fun say(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "waingchit")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale("my", "MM")
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts.shutdown()
        super.onDestroy()
    }
}
